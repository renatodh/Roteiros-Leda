package sorting.variationsOfBubblesort;

import sorting.AbstractSorting;
import util.Util;

/**
 * The combsort algoritm.
 */
public class CombSort<T extends Comparable<T>> extends AbstractSorting<T> {
   @Override
   public void sort(T[] array, int leftIndex, int rightIndex) {
      if (leftIndex >= 0 && leftIndex <= rightIndex && rightIndex < array.length) {
         double numeroMagico = 1.25;
         int gap = (int) (rightIndex - leftIndex + 1 / numeroMagico);
         int index = 0;

         while (index <= rightIndex) {

            for (int j = leftIndex; j + gap <= rightIndex; j++) {
               if (array[j].compareTo(array[j + gap]) > 0) {
                  Util.swap(array, j, j + gap);

               }

            }
            gap = (int) (gap / numeroMagico);
            index++;

         }

      }
   }
}
